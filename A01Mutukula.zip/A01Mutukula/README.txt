My project(A01Mutukula) contains 3 web pages
1. Mutukula_shivaKumar.html - It is the home page which introduces me.
2. LoanEMIcalculator.html - It takes input from the user and displays calculated EMI per month.
3. contact.html - It is the contact page where users can enter their questions and submit.

corresponding css and js files attached.

1.Mutukula_shivaKumar.css 
2.LoanEMIcalculator.css
3.contact.css
4.LoanEMIcalculator.jss


